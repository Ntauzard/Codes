#include <iostream>

using namespace std;

int main()
{
    int arrVisitors[6];
    int less_visitors,most_visitors;
    int l_day = 1, h_day = 1;

    for(int k=0; k<6; k++)
    {
        cout << "Enter the number of visitors for day " <<(k+1)<< ": ";
        cin >> arrVisitors[k];
    }
    cout << "\nList of visitors per day" <<endl;
    for(int k = 0; k<6; k++)
    {
        cout << "Day" <<(k+1) <<": " <<arrVisitors[k] << endl;
    }
    less_visitors = arrVisitors[0];
    for(int k=1; k<6; k++)
    {
        if(arrVisitors[k]<less_visitors)
        {
            less_visitors = arrVisitors[k];
            l_day = k+1;
        }
    }
    cout <<"\nDay with the least number of visitors is day "
         <<l_day << " with "<< less_visitors <<" visitors"<<endl;

    most_visitors = arrVisitors[0];
    for(int k=1; k<6; k++)
    {
        if(arrVisitors[k]>most_visitors)
        {
            most_visitors=arrVisitors[k];
            h_day = k+1;
        }
    }
    cout <<"Day with the most number of visitors is day "
         <<h_day <<" with " << most_visitors << " visitors"<<endl;

    return 0;
}
