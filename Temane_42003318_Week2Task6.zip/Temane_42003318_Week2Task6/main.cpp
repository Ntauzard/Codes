#include <iostream>
#include <time.h>

using namespace std;
void doWhileLoop()
{
  srand(time(0));
    int value = 0, highest=0, lowest=100;

    cout << "List of 10 random values:While Loop" << endl;
    int k = 1;
    while(k <=10)
    {
       value = rand() % 100 + 1;
       if(value > highest)
        highest = value;
       if(value < lowest)
        lowest = value;
       cout << value << endl;

       k++;
    }
    cout << "The highest value is: " << highest << endl;
    cout << "The lowest value is: " << lowest << endl;

}
void doDoWhileLoop()
{

    srand(time(0));
    int value = 0, highest=0, lowest=100;


    int k=1;
    do
    {

       cout << "The list of 10 random values- doWhileLoop: " << endl;
       value = rand() % 100 + 1;
       if(value > highest)
        highest = value;
       if(value < lowest)
        lowest = value;
       cout << value << endl;
       k++;
    cout << "The highest value is: " << highest << endl;
    cout << "The lowest value is: " << lowest << endl;
    }
    while(k<=10);


}

int main()
{
    doWhileLoop();
    doDoWhileLoop();
    return 0;
}
